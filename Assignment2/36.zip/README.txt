Galaxy_zoo_CNN.py is written in python3. 
The code can be run either by using the bashrc file, or by opening the file with python3.

The Galaxy Zoo dataset can be found on Kaggle:
https://www.kaggle.com/c/galaxy-zoo-the-galaxy-challenge/data#_=_